# fullstack-admin

Build a MERN React Admin Dashboard | Redux Toolkit Query, Backend Focus, Deployment, Data Modeling

Video: https://www.youtube.com/watch?v=0cPCMIuDk2I

For all related questions and discussions about this project, check out the discord: https://discord.gg/2FfPeEk2mX
