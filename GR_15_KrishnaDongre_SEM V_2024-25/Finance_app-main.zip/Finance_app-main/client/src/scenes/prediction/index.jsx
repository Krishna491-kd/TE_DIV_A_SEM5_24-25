import { Button, CircularProgress, useTheme } from '@mui/material';
import React, { useState } from 'react';

const Prediction = () => {
  const [loading, setLoading] = useState(false);  // State to manage loading
  const theme = useTheme();

  const handleClick = () => {
    setLoading(true);  // Start loading when button is clicked

    // Simulate an async operation, then navigate to the URL
    setTimeout(() => {
      setLoading(false);  // Stop loading after async operation is done
      window.location.href = 'http://localhost:5173/predictions';  // Redirect to the link
    }, 2000);  // Simulate loading time (2 seconds)
  };

  return (
    <div
      style={{
        margin: "3% 45%"    // Centering the button horizontally
      }}
    >
      <Button
        onClick={handleClick}
        disabled={loading}  // Disable the button when loading
        sx={{
          backgroundColor: theme.palette.secondary.light,
          color: theme.palette.background.alt,
          fontSize: "14px",
          fontWeight: "bold",
          padding: "10px 30px",
          justifyContent: "center",
          alignItems: "center",
          display: "flex",
          width: "150px",  // Keep button width consistent when showing loader
        }}
      >
        {loading ? (  // Show loading spinner if `loading` is true
          <CircularProgress size={24} color="primary" />
        ) : (
          "Predict"  // Show "Predict" text when not loading
        )}
      </Button>
    </div>
  );
};

export default Prediction;
